# Wind-Drift Patch Tier Table

- Base file: `DFBHD.exe` (all tiers generated from it; each is standalone — pick one and put into game folder)
- How it works: every frame, the bullet gets pushed a little sideways by the map's wind. That's it. Bullets only — grenades and other thrown items don't feel the wind.
- Reference: in a full 45 kph gale, the push is about 737 units per frame before the tier divider

| Tier | File | Name | Gain | Accel / frame | % of gravity |
|---|---|---|---|---|---|
| K3 | DFBHD_wind_K3.exe | High wind | wind/8 | 92 | 55% |
| K4 | DFBHD_wind_K4.exe | Strong | wind/16 | 46 | 27.5% |
| K5 | DFBHD_wind_K5.exe | Medium-strong | wind/32 | 23 | 13.8% |
| K6 | DFBHD_wind_K6.exe | Medium | wind/64 | 11 | 6.6% | Recommended |
| K7 | DFBHD_wind_K7.exe | Mild | wind/128 | 5 | 3.0% | Recommended |
| K8 | DFBHD_wind_K8.exe | Faint | wind/256 | 2 | 1.2% |

## Install

1. Copy ONE tier exe from this zip into your game folder (the one where `DFBHD.exe` lives).
2. Launch that exe to play.
3. Want a different tier? Copy more exes in and launch whichever you feel like.
4. Uninstall = delete the exe you added.

## Want a different strength? Tune it yourself

No need to ask for new files. Open any tier exe in a hex editor and change ONE number in TWO places (both must be the same value):

- File offset `0x21001E`
- File offset `0x210029`

The number is the strength divider: bigger number = weaker wind (K3 is written as 3, K8 as 8, and so on). Valid range is 0-31, so you can dial in anything in between, like 5 or 11.

Warning: if you type 32 or higher it wraps around (37 behaves like 5), and 0 makes wind insanely strong. Stick to 1-31.

## Notes

- The patch never touches your original `DFBHD.exe` — worst case, delete the added exe and you're back to vanilla
